Java Reflection Console (jrc) - version 0.1a

# IMPORTANT #
This version has been compiled with java version 11.0.1
Make sure the classes your trying to access have been compiled
with version 11.0.1 or compile jrc again yourself

Note: modify the "-classpath" switch in the starter-script to include other libraries if needed

Console that allows you to browse, manipulate and execute compiled java code.
Invoke a method, create an instance, change a variable, etc. ...all at runtime.

run by executing jrc or jrc.bat inside a terminal from the classpath location ( where your .class files are )  
type 'help' for some helpful information

Additions planned:
    - supporting Array creation without workarounds.
    - supporting primitive types like 'int' instead of just 'java.lang.Integer' which can be problematic if methods are asking for those...
