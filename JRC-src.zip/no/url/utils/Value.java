package no.url.utils;

public class Value {
    private Object value;
    private Class<?> type;

    public Value(){
        this(null, null);
    }

    public void setValue(Object value, Class<?> type){
        this.value = value;
        this.type  = type;
    }

    public Value(Object value) {
        this(value, value.getClass());
    }

    public Value(Object value, Class<?> type){
        this.setValue(value);
        this.setType(type);
    }

    /**
     * @return the type
     */
    public Class<?> getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(Class<?> type) {
        this.type = type;
    }

    /**
     * @return the value
     */
    public Object getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(Object value) {
        this.value = value;
    }
}