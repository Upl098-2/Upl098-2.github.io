/*


    Last chance, turn back now...




































    Well, I've warned you...

*/
package no.url.jrc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

import no.url.utils.Value;

import java.util.HashMap;
import java.util.Iterator;
import java.lang.reflect.*;

public final class Main {

    // This String holds selectedClass's name
    private static String namespace = "<empty>";

    // Variables for selectedClass and its instance
    private static Class selectedClass = null;
    private static Object selectedInstance = null;

    // Map for allocated variables (var <type> <name> <value>)
    private static Map<String, no.url.utils.Value> objectTable = new HashMap<>();

    /**
     * This is the main function
     * This function will handle the user input loop
     * @param args Console Args
     * @throws IOException from BufferedReader::readLine
     */
    public static void main(String[] args) throws IOException {
        Tokenizer tk = new Tokenizer( "" );

        BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) );
        
        Boolean mainLoop = true;


        // Very huge chunk of code
        while( mainLoop ){
            System.out.print( "[" + namespace + "]$ " );
            tk.setSourceText( br.readLine() );

            try {
                List<String> tkns = tk.tokenize();

                // implement all console commands here
                switch( tkns.get( 0 ) ){
                    case "exit":
                        mainLoop = false;
                        break;
                    case "select":
                        if( tkns.size() < 2){
                            System.out.println( "Not enough arguments! Check 'help' for tips" );
                            break;
                        }
                        
                        selectedClass = Class.forName( tkns.get( 1 ) );
                        selectedInstance = null;
                        namespace = tkns.get( 1 );
                        
                        break;
                    case "dump":
                        if( tkns.size() < 2){
                            System.out.println( "Not enough arguments! Check 'help' for tips" );
                            break;
                        }
                        else if( selectedClass == null ){
                            System.out.println( "Select a class first!" );
                            break;
                        }
                        
                        String what = tkns.get( 1 );

                        if( what.equals( "methods" ) ){
                            Method methods[] = selectedClass.getDeclaredMethods();

                            System.out.println( "------ Methods in '" + namespace + "' ------"  );

                            for( Method m : methods ){
                                System.out.println( m.toString() );
                            }

                            System.out.println( "------ End Methods ------" );
                        }
                        else if( what.equals( "fields" ) ){
                            Field fields[] = selectedClass.getDeclaredFields();

                            System.out.println( "------ Fields in '" + namespace + "' ------"  );

                            for( Field f : fields ){
                                f.setAccessible( true );

                                if( (f.getModifiers() & Modifier.STATIC ) == 0 ){
                                    if( selectedInstance == null )System.out.println( "instance needed" );
                                    else {
                                        System.out.println( f.getName() + " : " + Modifier.toString( f.getModifiers() ) + " " + f.getType() + " = " + f.get( selectedInstance ) );
                                    }
                                }else
                                    System.out.println( f.getName() + " : " + Modifier.toString( f.getModifiers() ) + " " + f.getType() + " = " + f.get( null ) );
                            }

                            System.out.println( "------ End Fields ------" );
                        } 
                        else if( what.equals( "vars" ) ){
                            System.out.println( "------ Allocated Variables ------"  );

                            for( Map.Entry<String,no.url.utils.Value> v : objectTable.entrySet() ){
                                String name = v.getKey();
                                no.url.utils.Value val = v.getValue();

                                System.out.println( name + " : " + val.getType().toString() + " = " + val.getValue().toString() );
                            }

                            System.out.println( "------ End Variables ------" );
                        }

                        break;
                    case "var":
                        if( tkns.size() < 4 ){
                            System.out.println( "Not enough arguments! Check 'help' for tips" );
                            break;
                        }
                        
                        String var_type = tkns.get( 1 );
                        String name     = tkns.get( 2 );
                        String str_val  = tkns.get( 3 );

                        Class paramType[] = new Class[]{ String.class };

                        try {
                            Constructor obj_constructor = Class.forName( var_type ).getConstructor( paramType );

                            objectTable.computeIfAbsent( name, ignored -> new Value())
                                .setValue( (Object)obj_constructor.newInstance( new Object[]{ (Object)str_val } ), Class.forName( var_type ) );
                        } catch(NoSuchMethodException noconstructorex){
                            System.out.println( "Uh, oh! Can't convert given value to Field type\nReason: No such constructor!" );
                            noconstructorex.printStackTrace();
                        } catch(InstantiationException instex){
                            System.out.println( "Uh, oh! The underlying class is abstract? What are you trying to instanciate?" );
                            instex.printStackTrace();
                        } catch ( IllegalArgumentException illargex) {
                            System.out.println( "Uh, oh! But I thought the BReader converted to Strings...");
                            illargex.printStackTrace();
                        } catch( InvocationTargetException itex ){
                            System.out.println( "Uh, oh! The Object class threw an exception." );
                            itex.printStackTrace();
                        } catch( ClassNotFoundException cnfex ){
                            System.out.println( "Uh, oh! That type doesn't exist" );
                            cnfex.printStackTrace();
                        }

                        break;
                    case "set":
                        if( tkns.size() < 3 ){
                            System.out.println( "Not enough arguments! Check 'help' for tips" );
                            break;
                        }
                        else if( selectedClass == null ){
                            System.out.println( "Select a class first!" );
                            break;
                        }

                        String fld_name  = tkns.get( 1 );
                        String str_value = tkns.get( 2 );

                        Field fld = selectedClass.getDeclaredField( fld_name );
                        Class<?> type = fld.getType();

                        fld.setAccessible( true );
                        
                        if( tkns.size() > 3 && tkns.get( 3 ).equals( "force" ) ){
                            Field modField = Field.class.getDeclaredField( "modifiers" );
                            modField.setAccessible( true );
                            modField.setInt( fld, fld.getModifiers() & ~Modifier.FINAL );
                        }

                        Class paramTypes[] = new Class[]{ String.class };

                        try {
                            Constructor constructor = type.getConstructor( paramTypes );

                            fld.set( type, constructor.newInstance( new Object[]{ (Object)str_value } ) );
                        } catch(NoSuchMethodException noconstructorex){
                            System.out.println( "Uh, oh! Can't convert given value to Field type\nReason: No such constructor!" );
                            noconstructorex.printStackTrace();
                        } catch(InstantiationException instex){
                            System.out.println( "Uh, oh! The underlying class is abstract? What are you trying to instanciate?" );
                            instex.printStackTrace();
                        } catch ( IllegalArgumentException illargex) {
                            System.out.println( "Uh, oh! But I thought the BReader converted to Strings...");
                            illargex.printStackTrace();
                        } catch( InvocationTargetException itex ){
                            System.out.println( "Uh, oh! The Object class threw an exception." );
                            itex.printStackTrace();
                        }
                        break;
                    case "instance":
                        Class[] iptypes = new Class[tkns.size()-1];
                        Object[] ipvals = new Object[tkns.size()-1];

                        try {
                            for(int i = 1; i < tkns.size(); i++){

                                iptypes[i-1] = objectTable.get( tkns.get( i ) ).getType();
                                ipvals[i-1]  = objectTable.get( tkns.get( i ) ).getValue();
                            }
                        } catch( ClassCastException ccex ){
                            System.out.println( "Uh, oh! I don't event know how this error could possibly happen..." );
                            ccex.printStackTrace();
                        } catch( NullPointerException npex ){
                            System.out.println( "Uh, oh! One of your specified variables doesn't exist!" );
                            npex.printStackTrace();
                        }

                        instanciate( iptypes, ipvals );
                        break;
                    case "instance_typed":
                        if( (tkns.size() - 1) % 2 != 0 ){
                            System.out.println( "Need an even amount of arguments (type-name-pairs)" );
                            break;
                        }

                        Class[] itptypes = new Class[(tkns.size()-1)/2];
                        Object[] itpvals = new Object[(tkns.size()-1)/2];

                        try {
                            for(int i = 1; i < tkns.size(); i+=2){

                                String itype = tkns.get( i );
                                String iname = tkns.get( i + 1 );

                                itptypes[i-1] = Class.forName( itype );
                                itpvals[i-1]  = objectTable.get( iname ).getValue();
                            }
                        } catch( ClassCastException ccex ){
                            System.out.println( "Uh, oh! I don't event know how this error could possibly happen..." );
                            ccex.printStackTrace();
                        } catch( NullPointerException npex ){
                            System.out.println( "Uh, oh! One of your specified variables doesn't exist!" );
                            npex.printStackTrace();
                        } catch( ClassNotFoundException cnfex ){
                            System.out.println( "Uh, oh! That type doesn't exist!" );
                            cnfex.printStackTrace();
                        }

                        instanciate( itptypes, itpvals );
                        break;
                    case "invoke":
                        if( tkns.size() < 2 ){
                            System.out.println( "Not enough arguments! Check 'help' for tips!" );
                            break;
                        }

                        String mname = tkns.get( 1 );

                        Class[] ptypes = new Class[tkns.size()-2];
                        Object[] pvals = new Object[tkns.size()-2];

                        try {
                            for(int i = 2; i < tkns.size(); i++){

                                ptypes[i-2] = objectTable.get( tkns.get( i ) ).getType();
                                pvals[i-2]  = objectTable.get( tkns.get( i ) ).getValue();
                            }
                        } catch( ClassCastException ccex ){
                            System.out.println( "Uh, oh! I don't event know how this error could possibly happen..." );
                            ccex.printStackTrace();
                        } catch( NullPointerException npex ){
                            System.out.println( "Uh, oh! One of your specified variables doesn't exist!" );
                            npex.printStackTrace();
                        }

                        System.out.println( "Method returned value: " + invoke_method( mname, ptypes, pvals ) );
                        break;
                    case "invoke_typed":
                        if( tkns.size() < 2 ){
                            System.out.println( "Not enough arguments! Check 'help' for tips!" );
                            break;
                        }

                        String mtname = tkns.get( 1 );
                        
                        if( (tkns.size() - 2 ) % 2 != 0 ){
                            System.out.println( "Need an even amount of arguments (type-name-pairs)" );
                            break;
                        }

                        Class[] pttypes = new Class[(tkns.size()-2)/2];
                        Object[] ptvals = new Object[(tkns.size()-2)/2];

                        try {
                            for(int i = 2; i < tkns.size(); i+=2){

                                String pttype = tkns.get( i );
                                String ptname = tkns.get( i + 1 );

                                pttypes[i-2] = Class.forName( pttype );
                                ptvals[i-2]  = objectTable.get( ptname ).getValue();
                            }
                        } catch( ClassCastException ccex ){
                            System.out.println( "Uh, oh! I don't event know how this error could possibly happen..." );
                            ccex.printStackTrace();
                        } catch( NullPointerException npex ){
                            System.out.println( "Uh, oh! One of your specified variables doesn't exist!" );
                            npex.printStackTrace();
                        } catch( ClassNotFoundException cnfex ){
                            System.out.println( "Uh, oh! That type doesn't exist!" );
                            cnfex.printStackTrace();
                        }

                        System.out.println( "Method returned value: " + invoke_method( mtname, pttypes, ptvals ) );
                        break;
                    case "save":
                        if(selectedInstance == null){
                            System.out.println( "Needs instance." );
                            break;
                        }
                        if( tkns.size() < 2 ){
                            System.out.println( "Not enough arguments! Use 'help' to get tips!" );
                            break;
                        }

                        objectTable.computeIfAbsent( tkns.get( 1 ), ignored -> new Value() )
                            .setValue( (Object)selectedInstance, selectedClass );
                        break;
                    case "clear":
                        System.out.print("\033c");
                        break;
                    case "help":
                        // TODO: Implement specific command help
                        printUsage();
                        break;
                    default:
                        System.out.println( "Error: Unrecognized command: '" + tkns.get( 0 ) + "'" );
                        break;
                }

            // All exceptions that could be thrown, except for some Map related ones, and the ones when invoking a method/constructor
            } catch(IllegalStateException isex){
                System.out.println( "Uh, oh! Seems like you mistyped something!" );
                isex.printStackTrace();
            } catch(IllegalAccessException iaex ){
                System.out.println( "Uh, oh! Seems like setAccessible(true) failed, and the field is still final/private!");
                iaex.printStackTrace();
            } catch(ClassNotFoundException cnfex){
                System.out.println( "Uh, oh! Seems like that class doesn't exist!" );
                cnfex.printStackTrace();
            } catch(SecurityException secex ){
                System.out.println( "Uh, oh! Seems like that class doesn't allow inspection!\nIt must be disabled manually first." );
                secex.printStackTrace();
            } catch(NoSuchFieldException nsfex ){
                System.out.println( "Uh, oh! Seems like that class doesn't declare that field!" );
                nsfex.printStackTrace();
            }

        }
        
        System.out.println( "------ End of main ------" );
    
        System.exit( 0 );
    }

    /**
     * Print usage information
     */
    private static void printUsage() {
        System.out.println( "Java Reflector Console (jrc) - version 0.1a\n" );
        System.out.println( "help                               - Print this message" );
        System.out.println( "select <class>                     - Select class with name <class>" );
        System.out.println( "dump <type>                        - Dump all <type>s" );
        System.out.println( "    where <type> is one of:" );
        System.out.println( "        methods, fields, vars" );
        System.out.println( "set <name> <value> <force>          - Change the value of <name> to <value>, if <force> is set, ignore final modifier" );
        System.out.println( "\t<name> must exist in selected class\n\t<value> must be convertible to <name>'s type\n\t<force> can be set to 'force' to try and mitigate the 'final' modifier,\n\t        You must set this on the first time you access the field, or it will lock up.\n\t        However java may disallow doing that in the future!\n\t        Also the binaries may not see the changes made as these fields are interpreted as constants" );
        System.out.println( "var <type> <name> <value>           - create variable to use in function calls" );
        System.out.println( "instance <arg>...                   - create an instance of the selected class for non-static operations" );
        System.out.println( "instance_typed <type,arg>...        - same as 'instance', but argument types can be specified manually" );
        System.out.println( "invoke <method> <arg>...            - invoke a method and print its return value" );
        System.out.println( "invoke_typed <method> <type,arg>... - same as 'invoke', but argument types can be specified manually" );
        System.out.println( "save <name>                         - save the selected instance as a variable for later use" );
        System.out.println( "clear                               - attempt to clear console window (might only work on linux teminals)" );
        System.out.println( "exit                                - Exit to shell" );
        System.out.println( "\n\nInfo: classes from packages require their full package path (e.g. java.lang.String)\narguments with '...' are optional\nArray support will be comming at some point\nAlso escaping special chars in strings is not supported, yet (e.g. \\\")\nand well use of special chars (e.g. \\n)." );
        System.out.println( "\n\nThis source code is obfuscated by making it be horrible (decompiling at own risk)." );
    }

    /**
     * Invoke method in selectedClass
     * @param methodName The method's name
     * @param params_types The types of the parameters
     * @param param_values The values of the parameters (can all be Objects)
     * @return The invoked methods return value or null
     * @throws SecurityException if we're not allowed to access that method...
     * @throws IllegalAccessException idk I forgot
     */
    private static Object invoke_method( String methodName, Class[] params_types, Object[] param_values ) throws SecurityException, IllegalAccessException {
        if( selectedClass == null ){
            System.out.println( "Select a class first!" );
            return null;
        }

        try {
            Method m = selectedClass.getDeclaredMethod( methodName, params_types);

            m.setAccessible( true );

            if( (m.getModifiers() & Modifier.STATIC) == 0 && selectedInstance == null ){
                System.out.println( "Need an instance" );
                return null;
            } 

            return m.invoke( selectedInstance, param_values );
        
        } catch(NoSuchMethodException noconstructorex){
            System.out.println( "Uh, oh! Can't convert given value to Field type\nReason: No such constructor!" );
            noconstructorex.printStackTrace();
        } catch ( IllegalArgumentException illargex) {
            System.out.println( "Uh, oh! But I thought the BReader converted to Strings...");
            illargex.printStackTrace();
        } catch( InvocationTargetException itex ){
            System.out.println( "Uh, oh! The Object class threw an exception." );
            itex.printStackTrace();
        }
        
        return null;
    }

    /**
     * Create an instance of the selected class and save it as selectedInstance
     * @param itypes Parameter Types
     * @param ivalues Parameter Values
     * @throws SecurityException still not allowed to access
     * @throws IllegalAccessException still don't know
     */
    private static void instanciate(Class[] itypes, Object[] ivalues ) throws SecurityException, IllegalAccessException{
        if( selectedClass == null ){
            System.out.println( "Select a class first!" );
            return;
        }

        try {
            Constructor iconstructor = selectedClass.getConstructor( itypes );

            selectedInstance = iconstructor.newInstance( ivalues );
        } catch(NoSuchMethodException noconstructorex){
            System.out.println( "Uh, oh! Can't convert given value to Field type\nReason: No such constructor!" );
            noconstructorex.printStackTrace();
        } catch(InstantiationException instex){
            System.out.println( "Uh, oh! The underlying class is abstract? What are you trying to instanciate?" );
            instex.printStackTrace();
        } catch ( IllegalArgumentException illargex) {
            System.out.println( "Uh, oh! But I thought the BReader converted to Strings...");
            illargex.printStackTrace();
        } catch( InvocationTargetException itex ){
            System.out.println( "Uh, oh! The Object class threw an exception." );
            itex.printStackTrace();
        }
    }
}
