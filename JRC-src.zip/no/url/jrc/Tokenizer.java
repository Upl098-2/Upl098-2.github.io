package no.url.jrc;

import java.util.ArrayList;
import java.util.List;

public class Tokenizer {

    private String source;
    private int position;

    /**
     * Creates tokens from Text
     * @param text Source text for Tokenizer
     */
    public Tokenizer(String text){
        this.source = text;
        this.position = 0;
    }

    public void resetPosition(){
        this.position = 0;
    }

    public void setSourceText(String text){
        resetPosition();
        this.source = text;
    }

    public List<String> tokenize() throws IllegalStateException {
        List<String> tkns = new ArrayList<String>();

        StringBuilder sb = new StringBuilder();
        Character current;


        boolean inString = false;

        for(; this.position < this.source.length(); this.position++){
            current = this.source.charAt( this.position );

            // System.out.println( "[Info]: Next char is: '" + current.toString() + "'" );
            // System.out.println( "[Info]: IsWS and NoString? " + ((Boolean)(current.equals(' ') && !inString)).toString() );

            if(current.equals('\n'))break;
            
            if( current.equals('"') ){
                inString = !inString;

                if( !inString ){
                    tkns.add( sb.toString() );
                    sb = new StringBuilder();
                }
            }
            else if( current.equals(' ') && !inString ){
                if( sb.length() > 0 ){
                    tkns.add( sb.toString() );
                    sb = new StringBuilder();
                }
            }
            else sb.append( current );

        }

        if( inString == true )throw new IllegalStateException( "Error: Can't end on an open string!" );
    
        if( sb.length() > 0 )tkns.add( sb.toString() );

        return tkns;
    }
}
